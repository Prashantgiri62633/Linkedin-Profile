$(function() {
    var header = $(".navigation");
    $(window).scroll(function() {    
        var scroll = $(window).scrollTop();
    
        if (scroll >= 10) {
            header.addClass('fixed-header');
        } else {
            header.removeClass('fixed-header');
        }
    });
});	

/// Read More Content

function myFunction() {
    var dots = document.getElementById("dots");
    var moreText = document.getElementById("more");
    var btnText = document.getElementById("myBtn");
  
    if (dots.style.display === "none") {
      dots.style.display = "inline";
      btnText.innerHTML = "Show more <i class='fa fa-sort-down'></i>";
      moreText.style.display = "none";
    } else {
      dots.style.display = "none";
      btnText.innerHTML = "Show less <i class='fa fa-sort-down'></i>";
      moreText.style.display = "inline";
    }
  }


  function myFunction() {
    var dots = document.getElementById("group");
    var moreText = document.getElementById("show-more");
    var btnText = document.getElementById("group-btn");
  
    if (dots.style.display === "none") {
      dots.style.display = "inline";
      btnText.innerHTML = "Show 8 more Groups <i class='fa fa-sort-down'></i>";
      moreText.style.display = "none";
    } else {
      dots.style.display = "none";
      btnText.innerHTML = "Show fewer groups <i class='fa fa-sort-down'></i>";
      moreText.style.display = "inline";
    }
  }

  function myFunction() {
    var dots = document.getElementById("profile");
    var moreText = document.getElementById("profile-more");
    var btnText = document.getElementById("profile-btn");
  
    if (dots.style.display === "none") {
      dots.style.display = "inline";
      btnText.innerHTML = "Show more profiles <i class='fa fa-sort-down'></i>";
      moreText.style.display = "none";
    } else {
      dots.style.display = "none";
      btnText.innerHTML = "Show fewer profiles <i class='fa fa-sort-down'></i>";
      moreText.style.display = "inline";
    }
  }